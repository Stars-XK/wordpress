<?php
/**
 * The template for displaying the footer
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package GodMainCode
 */

?>

<footer id="colophon" class="site-footer">
    <div class="container">
        <div class="footer-content">
            <div class="footer-section">
                <h3 class="footer-title">关于我们</h3>
                <p class="footer-text"><?php echo esc_html( get_theme_mod( 'godmaincode_footer_about', 'GodMainCode - 现代化WordPress主题，为您提供优雅的网站体验。' ) ); ?></p>
            </div>

            <div class="footer-section">
                <h3 class="footer-title">快速链接</h3>
                <ul class="footer-links">
                    <li><a href="<?php echo esc_url( home_url( '/' ) ); ?>">首页</a></li>
                    <li><a href="<?php echo esc_url( get_permalink( get_option( 'page_for_posts' ) ) ); ?>">博客</a></li>
                    <li><a href="#">关于我们</a></li>
                    <li><a href="#">联系</a></li>
                </ul>
            </div>

            <div class="footer-section">
                <h3 class="footer-title">联系方式</h3>
                <ul class="footer-links">
                    <li>邮箱: info@godmaincode.com</li>
                    <li>微信: GodMainCode</li>
                </ul>
            </div>
        </div>

        <div class="footer-bottom">
            <div class="footer-social">
                <a href="#" aria-label="GitHub">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"/>
                    </svg>
                </a>
                <a href="#" aria-label="微信">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M8.691 2.188c-3.738 0-6.774 3.035-6.774 6.774 0 3.537 2.746 6.413 6.274 6.764-.063-.447-.063-.918-.063-1.441 0-3.249 2.638-5.884 5.889-5.884 3.251 0 5.891 2.635 5.891 5.884 0 3.248-2.64 5.884-5.891 5.884-1.614 0-3.014-.523-4.187-1.426-.154-.116-.184-.2-.184-.316 0-.066.014-.184.014-.28 0-.063-.014-.125-.014-.172 0-.062.041-.123.041-.213 0-.066-.041-.123-.041-.213 0-.07.027-.14.041-.192.082-.373.246-.633.492-.887.246-.254.582-.485.969-.607.246-.08.385-.247.385-.47 0-.123-.082-.247-.164-.37-.246-.373-.369-.804-.369-1.29 0-1.002.82-1.846 1.846-1.846.697 0 1.321.285 1.774.738.287-.396.861-.656 1.477-.656 1.106 0 2.002.896 2.002 2.002 0 1.106-.896 2.002-2.002 2.002-.738 0-1.372-.37-1.703-.895-.287.246-.697.402-1.127.402-.99 0-1.795-.804-1.795-1.795 0-.99.805-1.795 1.795-1.795.697 0 1.288.37 1.64.896.328-.246.697-.396 1.127-.396 1.29 0 2.338 1.049 2.338 2.339 0 1.29-1.048 2.338-2.338 2.338-.697 0-1.321-.285-1.774-.738-.287.396-.861.656-1.477.656-.41 0-.697-.103-.861-.205-.082.014-.164.014-.246.014-1.395 0-2.531-1.133-2.531-2.531 0-1.395 1.136-2.531 2.531-2.531 1.395 0 2.531 1.136 2.531 2.531 0 .801-.37 1.52-.945 1.998.205.066.41.117.615.117 1.395 0 2.531 1.136 2.531 2.531 0 1.395-1.136 2.531-2.531 2.531-.82 0-1.549-.395-2.002-1.002-.123.205-.41.344-.697.344-1.066 0-1.933-.867-1.933-1.933 0-.285.063-.562.172-.82-.328-.087-.656-.253-.902-.492-.41.192-.881.295-1.372.295z"/>
                    </svg>
                </a>
                <a href="#" aria-label="邮箱">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
                        <polyline points="22,6 12,13 2,6"></polyline>
                    </svg>
                </a>
            </div>
            <p class="footer-copyright">
                <?php echo esc_html( get_theme_mod( 'godmaincode_footer_copyright', '© ' . date( 'Y' ) . ' GodMainCode. All rights reserved.' ) ); ?>
            </p>
        </div>
    </div>
</footer>

</div>

<?php wp_footer(); ?>

</body>
</html>